from django.shortcuts import render,redirect
from SPTapp.models import Staff,Subject,Session_Year,Student,Attendance,Attendance_Report,StudentResult,Course,Student_Notification


def HOME(request):
    student_id = Student.objects.get(admin = request.user.id)
    Attendance_total = Attendance_Report.objects.filter(student_id = student_id).count()
    course = Course.objects.get(id=student_id.course_id.id )
    Subjects = Subject.objects.filter(course = course).count()
    session_Year = Session_Year.objects.get(id=student_id.session_year_id.id)
    student = Student.objects.filter(admin = request.user.id)
    for i in student:
        student_id = i.id
        notification = Student_Notification.objects.filter(student_id = student_id)

    context = {
        'Attendance_total' : Attendance_total,
        'Subjects' : Subjects,
        'course' : course,
        'session_Year' : session_Year,
        'session_Year' : session_Year,
        'notification':notification,
    }
    
 
    return render(request,'Student/home.html',context)

def STUDENT_VIEW_ATTENDANCE(request):
    student = Student.objects.get(admin = request.user.id)
    subjects = Subject.objects.filter(course = student.course_id)
    action = request.GET.get('action')

    get_subject = None
    attendance_report = None
    if action is not None:
        if request.method == "POST":
            subject_id = request.POST.get('subject_id')
            get_subject = Subject.objects.get(id = subject_id)

            attendance_report = Attendance_Report.objects.filter(student_id = student, attendance_id__subject_id = subject_id)

    context = {
       'subjects':subjects,
       'action':action,
       'get_subject':get_subject,
       'attendance_report':attendance_report,
    }
    return render(request,'Student/view_attendance.html',context)    

def VIEW_RESULT(request):
    student = Student.objects.get(admin = request.user.id)
    result = StudentResult.objects.filter(student_id = student)

    context = {
        'result':result,
        

    }
    return render(request,'Student/view_result.html',context)